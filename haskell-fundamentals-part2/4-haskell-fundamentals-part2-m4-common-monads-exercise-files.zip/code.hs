
import Control.Monad.Reader
import Control.Monad.State
import Control.Monad.ST
import Data.STRef

getFirst :: Reader String String
getFirst = do
  name <- ask
  return (name ++ " woke up")

getSecond :: Reader String String
getSecond = do
  name <- ask
  return (name ++ " wrote some Haskell")

getStory :: Reader String String
getStory = do
  first <- getFirst
  second <- getSecond
  return ("First, " ++ first ++ 
          ". Second, " ++ second ++ ".")

harmonicStep :: State (Double,Double) Double
harmonicStep = do
  (position,velocity) <- get
  let acceleration = (-0.01 * position)
      velocity'    = velocity + acceleration
      position'    = position + velocity'
  put (position',velocity')
  return position

harmonic :: State (Double,Double) [Double]
harmonic = do
  position <- harmonicStep
  laterPositions <- harmonic
  return (position : laterPositions)

positions :: [Double]
positions = evalState harmonic (1,0)

sumST :: [Int] -> STRef s Int -> ST s ()
sumST []       accumRef = return ()
sumST (x : xs) accumRef = do
  accum <- readSTRef accumRef
  writeSTRef accumRef (x + accum)
  sumST xs accumRef

sum' :: [Int] -> Int
sum' xs = runST $ do
  accumRef <- newSTRef 0
  sumST xs accumRef
  readSTRef accumRef