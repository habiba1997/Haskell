The code.hs file contains the functions defined in this module. 

You need to have the Haskell Platform (http://www.haskell.org/platform/) installed to run the code.

Once the Haskell Platform is installed, you can load it into GHCi by either double clicking on the code.hs file, or typing "ghci code.hs" on a command line.