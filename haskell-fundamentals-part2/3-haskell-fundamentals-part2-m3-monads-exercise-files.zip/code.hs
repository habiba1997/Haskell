-- imported modules
import qualified Data.Set
import qualified Data.Sequence

-- Clip: Common Functionality for all Monads

join :: Monad m => m (m a) -> m a
join mmx = mmx >>= id

-- Clip: do-Notation

addM :: Monad m => m Int -> m Int -> m Int
addM mx my =
  mx >>= (\x -> my >>= (\y -> return (x + y)))

addM' :: Monad m => m Int -> m Int -> m Int
addM' mx my = do
  x <- mx
  y <- my
  return (x + y)

people = ["Alice", "Bob", "Eve"]
items = ["car", "puppy"]
missing = do
  person <- people
  item   <- items
  return (person ++ " lost a " ++ item)